class Snake{
private:
	float mouseOscilation;
	float tailOscilation;
	Shape Cerculet;
public:
	bool Confucius;
	int ConfuciusLeft;
	bool ifUnder;
	bool UnderLeft;
	SimpleCorp Snake;
	Animation Head;
	Animation Under;
	Sprite Tale;
	Sprite Body[300];
	Vector2f trail[1500];
	int bodyParts;

	//snake cutting and decay, tailGrowth
	//inner workings
	Sprite* desenulDecay;
	int partiDecay;
	int stepsToDecay;
	void goDecay(){
		for (int i=0;i<partiDecay;i++){
			App.Draw(desenulDecay[i]);
		}
		if(stepsToDecay>0){
			for (int i=0;i<partiDecay;i++){
				desenulDecay[i].SetColor(Color(255,255,255,stepsToDecay));
			}
			stepsToDecay--;
		}
	}




	void CutTheSnake(int i){
		partiDecay=bodyParts-i;
		delete[] desenulDecay;
		desenulDecay = new Sprite[partiDecay];
		for(int it=0;it<partiDecay-1;it++){
			desenulDecay[it]=Body[it+i+1];
		}
		desenulDecay[partiDecay-1]=Tale;
		bodyParts=i-1;
		stepsToDecay=255;
	}



public:

	void AddBody(){
		bodyParts++;
	}

	void RemoveBody(int n){
		bodyParts-=n;
	}
	void Initialize(){
		Confucius=false;
		ifUnder=false;
		UnderLeft=false;
		mouseOscilation=0;
		tailOscilation=0;
		Cerculet=Shape::Circle(0,0,3,Color(0,0,0,30));

		Head.Initialize(App,40,40,Imagini.SnakeHead,15,10.f);
		Head.SetCenter(20,20);
		Head.Play();

		Under.Initialize(App,40,40,Imagini.SnakeUnder,5,1.f);
		Under.SetCenter(20,20);
		Under.Stop();

		Tale.SetImage(Imagini.SnakeTale);
		Tale.SetCenter(35,20);

		for (int i=0;i<300;i++){
			Body[i].SetImage(Imagini.SnakeBody);
			Body[i].SetCenter(10,10);
		}
		bodyParts=0;

		Snake.Initialize(30);
		Snake.x=290;Snake.y=300;
		Snake.SetSpeed(100.f);
		Snake.SetDirection(0.f);

		for(int i=0;i<1500;i++){
			trail[i].x=-100;
			trail[i].y=-100;
		}
	}

	void Go(){

		//some fail safe
		if(bodyParts>300){
			bodyParts=300;
		}
		if(bodyParts<1){
			bodyParts=1;
		}
		{//snake translation (acording to mouse)
			//ocilate the mouse
			float mx,my,temp;
			mx=App.GetInput().GetMouseX();
			my=App.GetInput().GetMouseY();
			temp=mx+sin(mouseOscilation)*(my-Snake.y);
			my=my-sin(mouseOscilation)*(mx-Snake.x);
			mx=temp;
			mouseOscilation+=0.1f;
			Cerculet.SetPosition(mx,my);
			temp=AngleToInterval(AngleToPoint(Snake.x,Snake.y,mx,my)-Snake.GetDirection());
			if(temp>50){
				Snake.ChangeDirection(100);
			}else if(temp<-50){
				Snake.ChangeDirection(-100);
			}else{
				Snake.ChangeDirection(temp*2);
			}
			//tail oscilation
			if(abs(App.GetInput().GetMouseX()-Snake.x)+abs(App.GetInput().GetMouseY()-Snake.y)>100){
				tailOscilation+=0.2f;
			}else{
				tailOscilation+=2.f;
			}
		}
		{//Calculations
			for (int i=1499;i>0;i--){
				trail[i]=trail[i-1];
			}
			trail[0]=Snake;
			//hitter
			for(int i=20;i<bodyParts;i++){
				if(abs(Snake.x-Body[i].GetPosition().x)+abs(Snake.y-Body[i].GetPosition().y)<10){
					CutTheSnake(i);
					break;
				}
			}


		}
		{//movement
			Snake.Go();
			for(int i=0;i<bodyParts;i++){
				Body[i].SetPosition(trail[3+4*i]);
				Body[i].SetRotation(AngleToPoint(trail[3+4*i].x,trail[3+4*i].y,trail[4*i].x,trail[4*i].y));
			}
			Tale.SetPosition(trail[3+4*bodyParts]);
			Tale.SetRotation(sin(tailOscilation)*10+AngleToPoint(trail[3+4*bodyParts].x,trail[3+4*bodyParts].y,trail[4*bodyParts].x,trail[4*bodyParts].y));

		}
		{//animations and placement
			Head.Go();
			Head.SetPosition(Snake);
			Head.SetRotation(Snake.GetRotation());


		}
		{//the decay
			goDecay();
		}
		{//Drawing the snake
			for (int i=0;i<bodyParts;i++){
				App.Draw(Body[i]);
			}
			if(!ifUnder){App.Draw(Head);}
			if(ifUnder){
				Snake.SetSpeed(5);
				if(Under.GetCurentFrame()>=4){
					Under.Pause();
				}else{
					Under.Play();
				}
				Under.Go();
				Under.SetPosition(Snake);
				Under.SetRotation(Snake.GetRotation());

				App.Draw(Under);
				UnderLeft=true;
			}else{
				if(UnderLeft){
					UnderLeft=false;
					Confucius=true;
					ConfuciusLeft=120;
				}
				Snake.SetSpeed(100);
				Under.GoToFirstFrame();
			}
			if(Confucius){
				ConfuciusLeft--;
				if(ConfuciusLeft<0){
					Confucius=false;
				}
			}
			App.Draw(Tale);
			App.Draw(Cerculet);
		}
	}
}snake;






class Spider{
	int miniPauze;

public:
	bool frenzy;
	bool savage;
	SimpleCorp Spider;
	Animation Spidi;
	float Target;
	int netNr;
	Sprite Net[100];
	int netTime[100];
	void AddNet(Vector2f punct){
		Net[netNr].SetPosition(punct);
		netTime[netNr]=30*30;
		netNr++;
	}

	void RunAway(Vector2f punct){
		Spider.SetDirection(AngleToPoint(Spider.x,Spider.y,punct.x,punct.y)+180);
		frenzy=true;
	}
	void Initialize(){
		Spidi.Initialize(App,40,40,Imagini.Spider,10,20.f);
		Spidi.Play();
		Spidi.SetCenter(20,20);

		Spider.Initialize(30);
		Spider.SetRotation(90);
		Spider.SetSpeed(100);
		Spider.x=200;
		Spider.y=200;

		for (int i=0;i<100;i++){
			Net[i].SetImage(Imagini.Net);
			Net[i].SetCenter(40,40);
		}

		miniPauze=3000;
		frenzy=false;
		netNr=0;
	}
	void Go(){


		if(!frenzy){
			if(sqrt((Spider.x-400)*(Spider.x-400)+(Spider.y-300)*(Spider.y-300))>450){
				Spider.SetDirection(AngleToPoint(Spider.x,Spider.y,400,300)+Random.Random(-45,45));
			}
			if(miniPauze<20){
				miniPauze++;
				Spidi.Pause();
			}else if(miniPauze<100){
				Spidi.Play();
				miniPauze++;
				Spider.Go();
			}else{
				miniPauze=0;
				Target=Random.Random(0,360);
				Spider.SetDirection(Target);
				if(Random.Random(0,30*120/FrameCount+1)<1){
					Vector2f p;
					p.x=Spider.x+Random.Random(-40,40);
					p.y=Spider.y+Random.Random(-40,40);
					AddNet(p);
				}

			}
		}else{
			Spider.Go();
			Spidi.Play();
		}



		for(int i=0;i<netNr;i++){
			netTime[i]--;
			if(netTime[i]<0){
				netNr--;
				Net[i]=Net[netNr];
				netTime[i]=netTime[netNr];
			}
		}
		for(int i=0;i<netNr;i++){
			App.Draw(Net[i]);
		}
		Spidi.SetPosition(Spider);
		Spidi.SetRotation(Spider.GetRotation());
		Spidi.Go();

	}



}spider;

class Worm{
	bool danger;
public:
	Sprite tunel[5];
	int tVisible[5];
	Vector2f Target;
	Animation rama;
	SimpleCorp Worm;
	bool above;
	int counter;

	void Initialize(){
		for (int i=0;i<5;i++){
			tunel[i].SetImage(Imagini.Tunnel);
			tunel[i].SetCenter(40,40);
		}
		rama.Initialize(App,40,40,Imagini.Worm,10,5.f);
		rama.SetCenter(20,20);
		rama.Play();
		Worm.Initialize(30);
		Worm.SetSpeed(100);
	}
	void Go(){
		if(above){
			counter--;
			if(counter<0){
				counter=50;
				above=false;
				int atempts=0;
				do{
					atempts++;
					float temp=Random.Random(0.f,6.283184f);
					Target.x=cos(temp)*165+Worm.x;
					Target.y=sin(temp)*165+Worm.y;

					danger=false;
					for(int i=0;i<dangerNumber;i++){
						if(sqrt((Target.x-dangerPoints[i].x)*(Target.x-dangerPoints[i].x)+(Target.y-dangerPoints[i].y)*(Target.y-dangerPoints[i].y))<20){
							danger=true;
						}
					}
				}while(atempts<100&&(sqrt((Target.x-400)*(Target.x-400)+(Target.y-300)*(Target.y-300))>450||danger));
				Worm.ToPoint(Target);
			}
		}else{
			Worm.Go();
			if(counter>0){
				counter--;
				tVisible[counter/10]=60;
				tunel[counter/10].SetPosition(Worm);
			}else if(counter>-20){
				counter--;
			}else{
				above=true;
				counter=240;

			}
		}


		for (int i=0;i<5;i++){
			if(tVisible[i]>0){
				App.Draw(tunel[i]);
				tVisible[i]--;
			}
		}
	}
	void addWorm(Vector2f point){
		wormCount++;
		Worm.x=point.x;
		Worm.y=point.y;
		Target=point;
		above=true;
		for(int i=0;i<5;i++){
			tVisible[i]=0;
		}
		counter=240;
	}












}worm[100];
