#include <SFML/System.hpp>
#include <SFML/Graphics.hpp>
#include <cmath>


namespace sf{

	class Animation:public Sprite{
	private:
		RenderWindow* Fereastra;
		bool Playing;
		Clock LastPlayed;
		Clock TheTime;
		int Width;
		int Height;
	//frames
		int Frames;
		float CurFrame;
		float FPS;

	public:
		inline void NextFrame();
		inline void PreviousFrame();
		void GoToFrame(float);
		inline void GoToLastFrame();
		inline void GoToFirstFrame();

		void Play();
		void Pause();
		void Stop();
		void SetFps(float);

		inline bool GetPlay();
		inline float GetCurentFrame();
		inline float GetFps();
	//init&go
		void Go();
		void Initialize(RenderWindow&,int,int,Image&,int,float);
	};


//Animation class......................................................................................................................................................................................
	inline void Animation::NextFrame(){
		GoToFrame(CurFrame+1<Frames?CurFrame+1:0);
	}
	inline void Animation::PreviousFrame(){
		GoToFrame(CurFrame-1>0?CurFrame-1:Frames-1);
	}
	void Animation::GoToFrame(float i){
		IntRect Crop((int)i*Width,0,((int)i+1)*Width,Height);
		SetSubRect(Crop);
		CurFrame=i;
		LastPlayed.Reset();
	}
	inline void Animation::GoToLastFrame(){
		GoToFrame(Frames-1);
	}
	inline void Animation::GoToFirstFrame(){
		GoToFrame(0);
	}
	void Animation::Play(){
		Playing=true;
		LastPlayed=TheTime;
	}
	void Animation::Pause(){
		Playing=false;
		TheTime=LastPlayed;
	}
	void Animation::Stop(){
		Playing=false;
		GoToFrame(0.f);
	}
	void Animation::SetFps(float f){
		FPS=f;
	}
	inline bool Animation::GetPlay(){
		return Playing;
	}
	inline float Animation::GetFps(){
		return FPS;
	}
	inline float Animation::GetCurentFrame(){
		return CurFrame;
	}
	void Animation::Go(){
		if(Playing){
			CurFrame=fmod((LastPlayed.GetElapsedTime()*FPS+CurFrame),Frames);
			GoToFrame(CurFrame);
			LastPlayed.Reset();
		}
	}
	void Animation::Initialize(RenderWindow& Fer,int w,int h, Image &Img, int NrFr, float NrFps){
	//Image
		Width=w;
		Height=h;
		SetImage(Img);
	//Window
		Fereastra=&Fer;
	//Frames
		CurFrame=0.f;
		Frames=NrFr;
		FPS=NrFps;
	//stoping the play
		Playing=false;
		GoToFirstFrame();
	}
}//exit the namespace











