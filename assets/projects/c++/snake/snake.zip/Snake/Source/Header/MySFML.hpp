#include <SFML/System.hpp>
#include <SFML/Graphics.hpp>
#include <SFML/Window.hpp>
#include <SFML/Network.hpp>
#include <SFML/Audio.hpp>
#include "Animation.hpp"
#include "Corp.hpp"
namespace sf{
///....................................................................................................................................................................................................
///My mini clases
///....................................................................................................................................................................................................
//class MyClock:public Clock{
//public:
//	void SetTime(float start){
//		Reset();
//		myStartTime+=start;
//	}
//	void AddTime(float time){
//		myStartTime+=time;
//	}
//	float GetRemainingTime(){
//		return -GetElapsedTime();
//	}
//};
//a usefull function:
inline float AngleToInterval(float unghi){
	unghi=fmod((360+fmod(unghi,360)),360);
	unghi=unghi>180?unghi-360.f:unghi;
	return unghi;
}
inline float AngleToPoint(float x, float y, float tx, float ty){
	return -(tx-x>0?180*atan((ty-y)/(tx-x))/3.141592 : 180+180*atan((ty-y)/(tx-x))/3.141592);
}
}//end of namespace

