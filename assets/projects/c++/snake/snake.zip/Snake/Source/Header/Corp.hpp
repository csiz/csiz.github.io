#include <SFML/System.hpp>
#include <SFML/Graphics.hpp>
#include <cmath>


namespace sf{//namespace begin
	class Corp:public Vector2f{
	private:
		RenderWindow* Fereastra;
		float SpeedX;
		float SpeedY;
		float Speed;
		float Direction;float Rotation;
	public:
		float Mass;
		void Initialize(RenderWindow&);
	//Apearance
		inline void SetRotation(float);
		inline float GetRotation();
	//movement
		void SetSpeed(float);
		void SetSpeed(float, float);
		void SetDirection(float);

		inline float GetDirection();
		inline float GetSpeed();
		inline float GetSpeedX();
		inline float GetSpeedY();

		inline void ToPoint(Vector2f);
		inline void ToPoint(float, float);
		inline void ChangeDirection(float);

		inline void Accelerate(float);
		inline void Accelerate(float,float);
		inline void Force(float);
		inline void Force(float, float);
	//interaction
		inline float GetDistance(float X, float Y);
	//go ofcourse
		inline void Go();
	};

//Corp class...........................................................................................................................................................................................
	inline void Corp::SetRotation(float r){
		Rotation=r;
	}
	inline float Corp::GetRotation(){
		return Rotation-Direction;
	}
	void Corp::SetSpeed(float speed){
		SpeedX=(float)cos(Direction/180*3.141592)*speed;
		SpeedY=(float)sin(Direction/180*3.141592)*speed;
		Speed=speed;
	}
	void Corp::SetSpeed(float X,float Y){
		SpeedX=X;
		SpeedY=Y;
		Speed=(float)sqrt(X*X+Y*Y);
		Direction=SpeedX>0?180*atan(SpeedY/SpeedX)/3.141592:180+180*atan(SpeedY/SpeedX)/3.141592;
	}
	void Corp::SetDirection(float dir){
		Direction=-dir;
		SpeedX=(float)cos(Direction/180*3.141592)*Speed;
		SpeedY=(float)sin(Direction/180*3.141592)*Speed;
	}
	inline float Corp::GetDirection(){
		return -Direction;
	}
	inline float Corp::GetSpeed(){
		return Speed;
	}
	inline float Corp::GetSpeedX(){
		return SpeedX;
	}
	inline float Corp::GetSpeedY(){
		return SpeedY;
	}
	inline void Corp::ToPoint(float X, float Y){
		X-=x;Y-=y;
		Direction=X>0?180*atan(Y/X)/3.141592:180+180*atan(Y/X)/3.141592;
		SpeedX=(float)cos(Direction/180*3.141592)*Speed;
		SpeedY=(float)sin(Direction/180*3.141592)*Speed;
	}
	inline void Corp::ToPoint(Vector2f v){
		ToPoint(v.x,v.y);
	}
	inline void Corp::ChangeDirection(float rel){
		SetDirection(-Direction+rel*Fereastra->GetFrameTime());
	}
	inline void Corp::Accelerate(float a){
		SetSpeed(Speed+a*Fereastra->GetFrameTime());
	}
	inline void Corp::Accelerate(float ax, float ay){
		SetSpeed(SpeedX+ax*Fereastra->GetFrameTime(),SpeedY+ay*Fereastra->GetFrameTime());
	}
	inline void Corp::Force(float f){
		Accelerate(f/Mass);
	}
	inline void Corp::Force(float fx,float fy){
		Accelerate(fx/Mass,fy/Mass);
	}
	inline float Corp::GetDistance(float X, float Y){
		return sqrt((X-x)*(X-x)+(Y-y)*(Y-y));
	}
	inline void Corp::Go(){
		x+=SpeedX*Fereastra->GetFrameTime();
		y+=SpeedY*Fereastra->GetFrameTime();
	}
	void Corp::Initialize(RenderWindow& Fer){
		Fereastra=&Fer;
	}
}//exit the namespace

namespace sf{//namespace begin
	class SimpleCorp:public Vector2f{
	private:
		float SpeedX;
		float SpeedY;
		float Speed;
		float Direction;float Rotation;
		float Constant;
	public:
		float Mass;
		void Initialize(float framerate);
	//Apearance
		inline void SetRotation(float);
		inline float GetRotation();
	//movement
		void SetSpeed(float);
		void SetSpeed(float, float);
		void SetDirection(float);

		inline float GetDirection();
		inline float GetSpeed();
		inline float GetSpeedX();
		inline float GetSpeedY();

		inline void ToPoint(Vector2f);
		inline void ToPoint(float, float);
		inline void ChangeDirection(float);

		inline void Accelerate(float);
		inline void Accelerate(float,float);
		inline void Force(float);
		inline void Force(float, float);
	//interaction
		inline float GetDistance(float X, float Y);
	//go ofcourse
		inline void Go();
	};

//Corp class...........................................................................................................................................................................................
	inline void SimpleCorp::SetRotation(float r){
		Rotation=r;
	}
	inline float SimpleCorp::GetRotation(){
		return Rotation-Direction;
	}
	void SimpleCorp::SetSpeed(float speed){
		SpeedX=(float)cos(Direction/180*3.141592)*speed;
		SpeedY=(float)sin(Direction/180*3.141592)*speed;
		Speed=speed;
	}
	void SimpleCorp::SetSpeed(float X,float Y){
		SpeedX=X;
		SpeedY=Y;
		Speed=(float)sqrt(X*X+Y*Y);
		Direction=SpeedX>0?180*atan(SpeedY/SpeedX)/3.141592:180+180*atan(SpeedY/SpeedX)/3.141592;
	}
	void SimpleCorp::SetDirection(float dir){
		Direction=-dir;
		SpeedX=(float)cos(Direction/180*3.141592)*Speed;
		SpeedY=(float)sin(Direction/180*3.141592)*Speed;
	}
	inline float SimpleCorp::GetDirection(){
		return -Direction;
	}
	inline float SimpleCorp::GetSpeed(){
		return Speed;
	}
	inline float SimpleCorp::GetSpeedX(){
		return SpeedX;
	}
	inline float SimpleCorp::GetSpeedY(){
		return SpeedY;
	}
	inline void SimpleCorp::ToPoint(float X, float Y){
		X-=x;Y-=y;
		Direction=X>0?180*atan(Y/X)/3.141592:180+180*atan(Y/X)/3.141592;
		SpeedX=(float)cos(Direction/180*3.141592)*Speed;
		SpeedY=(float)sin(Direction/180*3.141592)*Speed;
	}
	inline void SimpleCorp::ToPoint(Vector2f v){
		ToPoint(v.x,v.y);
	}
	inline void SimpleCorp::ChangeDirection(float rel){
		SetDirection(-Direction+rel*Constant);
	}
	inline void SimpleCorp::Accelerate(float a){
		SetSpeed(Speed+a);
	}
	inline void SimpleCorp::Accelerate(float ax, float ay){
		SetSpeed(SpeedX+ax*Constant,SpeedY+ay*Constant);
	}
	inline void SimpleCorp::Force(float f){
		Accelerate(f/Mass);
	}
	inline void SimpleCorp::Force(float fx,float fy){
		Accelerate(fx/Mass,fy/Mass);
	}
	inline float SimpleCorp::GetDistance(float X, float Y){
		return sqrt((X-x)*(X-x)+(Y-y)*(Y-y));
	}
	inline void SimpleCorp::Go(){
		x+=SpeedX*Constant;
		y+=SpeedY*Constant;
	}
	void SimpleCorp::Initialize(float framerate){
		Constant=1.f/framerate;
	}
}//exit the namespace
