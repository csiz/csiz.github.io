#include "Header/MySFML.hpp"

#include <cstdio>
#include <fstream>
using namespace std;
using namespace sf;

///....................................................................................................................................................................................................
//global data, characters
RenderWindow App(VideoMode(800,600,32),"Snake",Style::Titlebar);
int FrameRate;
Randomizer Random;
View GameScene;
bool Running;
long long int FrameCount;
bool danger;
double Score;
double MareScore;
Sprite Menu;
Sprite Background;
String Scorul;
String MareleScorul;
String ScrieScor("Score:",Font::GetDefaultFont(),14);


struct Imagini{
	Image SnakeHead;
	Image SnakeBody;
	Image SnakeTale;
	Image SnakeUnder;
	Image Spider;
	Image Net;
	Image Worm;
	Image Tunnel;
	Image Menu;
	Image Background;

}Imagini;

///....................................................................................................................................................................................................
//interaction variables
Vector2f dangerPoints[150];
int dangerNumber;
int wormCount;
int level;
///criters

#include "creatures.hpp"

///....................................................................................................................................................................................................
//function/threads
void focusWait(){
	String text("Waiting focus...",Font::GetDefaultFont(),30);
	text.SetPosition(50,50);
	text.SetColor(Color(0,0,0));
	App.Draw(Background);
	App.Draw(text);
	while(Running){
		App.Display();
		Event Event;
		while(App.GetEvent(Event)){
			if(Event.Type==Event::GainedFocus){
				return;
			}
		}
	}
}
void snakeCaptured(){
	delete[] snake.desenulDecay;
	snake.desenulDecay=new Sprite[0];
	snake.partiDecay=0;
	String text("The snake is dead...",Font::GetDefaultFont(),30);
	String text2(L"No shât:(",Font::GetDefaultFont(),10);
	text.SetPosition(50,50);
	text.SetColor(Color(0,0,0));
	text2.SetPosition(600,500);
	text2.SetColor(Color(0,0,0));
	App.Draw(Background);
	App.Draw(text);
	App.Draw(text2);
	FrameCount=0;

	GameScene.SetCenter(400,300);
	App.SetView(App.GetDefaultView());
	if(Score>MareScore){
		ofstream out("Objects/a");
		out<<Score;
		out.close();
	}
	while(Running){
		App.Display();
		Event Event;
		while(App.GetEvent(Event)){
			if(Event.Type==Event::KeyPressed&&Event.Key.Code==Key::Escape){
				Running=false;
				App.Close();
			}
		}
		FrameCount++;
		if(FrameCount>60){
			Running=false;
		}
	}
}

///....................................................................................................................................................................................................
int main(){
	//loading the images
	Imagini.SnakeHead.LoadFromFile("Objects/Snake/head.png");
	Imagini.SnakeTale.LoadFromFile("Objects/Snake/tale.png");
	Imagini.SnakeBody.LoadFromFile("Objects/Snake/body.png");
	Imagini.SnakeUnder.LoadFromFile("Objects/Snake/under.png");
	Imagini.Spider.LoadFromFile("Objects/Spider/spider.png");
	Imagini.Net.LoadFromFile("Objects/Spider/net.png");
	Imagini.Worm.LoadFromFile("Objects/Worms/worm.png");
	Imagini.Tunnel.LoadFromFile("Objects/Worms/tunnel.png");
	Imagini.Menu.LoadFromFile("Objects/menu.png");
	Imagini.Background.LoadFromFile("Objects/back.png");

	Menu.SetImage(Imagini.Menu);
	Background.SetImage(Imagini.Background);
	Background.SetCenter(30,30);
	Running=true;
mainMenu:
	//Setting the window properties
	FrameRate=60;
	App.SetFramerateLimit(FrameRate);
	App.Clear();
	App.Draw(Menu);
	{
		char buf[50];
		sprintf(buf, "%f", Score);
	Scorul.SetText(buf);
	}
	Scorul.SetColor(Color(0,0,0));
	Scorul.SetSize(20);
	Scorul.SetPosition(452,60);
	App.Draw(Scorul);
	{
	ifstream in("Objects/a");
	in>>MareScore;
	char buf[50];
	sprintf(buf, "%f", MareScore);
	MareleScorul.SetText(buf);
	MareleScorul.SetColor(Color(0,0,0));
	MareleScorul.SetSize(20);
	MareleScorul.SetPosition(452,26);
	in.close();
	}
	App.Draw(MareleScorul);

	while(Running){
		Event Event;
		while(App.GetEvent(Event)){
			if(Event.Type==Event::KeyPressed&&Event.Key.Code==Key::Escape){
				Running=false;
				App.Close();
			}
			if(Event.Type==Event::MouseButtonReleased){
				if(sqrt(pow(App.GetInput().GetMouseX()-650,2.f)+pow(App.GetInput().GetMouseY()-300,2.f))<50){
					goto gameLoop;
				}
				if(App.GetInput().GetMouseX()>600&&App.GetInput().GetMouseX()<700&&App.GetInput().GetMouseY()>540&&App.GetInput().GetMouseY()<590){
					Running=false;
					App.Close();
				}
			}
		}
		App.Clear();
        App.Draw(Menu);
        App.Draw(Scorul);
        App.Draw(MareleScorul);
		App.Display();
	}



gameLoop:
	Scorul.SetColor(Color(0,0,0));
	Scorul.SetSize(14);
	Scorul.SetPosition(730,580);
	ScrieScor.SetColor(Color(0,0,0));
	ScrieScor.SetPosition(688,580);

	Score=0;FrameCount=0;wormCount=0;
	GameScene=App.GetDefaultView();
	App.SetView(GameScene);
	//initializing objects
	snake.Initialize();
	spider.Initialize();
	for(int i=0;i<100;i++){
		worm[i].Initialize();
	}
	{Vector2f temp;
	temp.x=340;temp.y=300;
	worm[wormCount].addWorm(temp);
	temp.x+=20;
	temp.y-=10;
	worm[wormCount].addWorm(temp);
	temp.x+=20;
	worm[wormCount].addWorm(temp);
	temp.x+=20;
	temp.y-=15;
	worm[wormCount].addWorm(temp);
	temp.x+=20;
	worm[wormCount].addWorm(temp);
	temp.y+=5;
	temp.x+=20;
	worm[wormCount].addWorm(temp);
	}
	//starting the game loop



	while(Running){
		App.Clear(Color(255,255,255));
		App.Draw(Background);
		{
		char buf[50];
		sprintf(buf, "%f", Score);
		Scorul.SetText(buf);
		}
		App.Draw(Scorul);
		App.Draw(ScrieScor);
		FrameCount++;
		//handling events
		Event Event;
		while(App.GetEvent(Event)){
			if(Event.Type==Event::LostFocus){
				focusWait();
			}
			if(Event.Type==Event::KeyPressed&&Event.Key.Code==Key::Escape){
				Running=false;
				App.Close();
			}
			if(Event.Type==Event::KeyPressed&&Event.Key.Code==Key::Add){
				FrameRate++;
				App.SetFramerateLimit(FrameRate);
			}
			if(Event.Type==Event::KeyPressed&&Event.Key.Code==Key::Subtract){
				FrameRate--;
				if(FrameRate<20){
					FrameRate=20;
				}
				App.SetFramerateLimit(FrameRate);
			}
			if(Event.Type==Event::MouseWheelMoved){
				FrameRate+=Event.MouseWheel.Delta;
				if(FrameRate<30){
					FrameRate=30;
				}
				App.SetFramerateLimit(FrameRate);
			}
		}
		{//game workings (the actual game) (interactions)
			//puting some worms
			level=6+(int)(pow(FrameCount/30,0.9)/pow(20,0.9));
			if(level>100){
				level=100;
			}


			if(Random.Random(0.f,1.f)*30*20/(level-wormCount)<1){
				Vector2f Target;
				int atempts;
				do{
					atempts++;
					Target.x=Random.Random(0,800);
					Target.y=Random.Random(0,600);
					danger=false;
					for(int i=0;i<dangerNumber;i++){
						if(atempts<100&&(sqrt((Target.x-dangerPoints[i].x)*(Target.x-dangerPoints[i].x)+(Target.y-dangerPoints[i].y)*(Target.y-dangerPoints[i].y))<20)){
							danger=true;
						}
					}
				}while(danger);
				worm[wormCount].addWorm(Target);
			}

			dangerNumber=0;
			for(int i=0;i<snake.bodyParts;i+=3){
				dangerPoints[dangerNumber]=snake.Body[i].GetPosition();
				dangerNumber++;
			}
			for(int i=0;i<wormCount;i++){
				dangerPoints[dangerNumber]=worm[i].Target;
				dangerNumber++;
			}


			float tempSmallest=100;
			int tempSmallestNumber;
			for(int i=0;i<dangerNumber;i++){
				if(sqrt((spider.Spider.x-dangerPoints[i].x)*(spider.Spider.x-dangerPoints[i].x)+(spider.Spider.y-dangerPoints[i].y)*(spider.Spider.y-dangerPoints[i].y))<tempSmallest){
					tempSmallest=sqrt((spider.Spider.x-dangerPoints[i].x)*(spider.Spider.x-dangerPoints[i].x)+(spider.Spider.y-dangerPoints[i].y)*(spider.Spider.y-dangerPoints[i].y));
					tempSmallestNumber=i;
				}
			}
			if(tempSmallest<40){
				spider.RunAway(dangerPoints[tempSmallestNumber]);
			}else{
				spider.frenzy=false;
			}


			if(snake.Confucius){
				spider.frenzy=false;
				spider.Spider.SetDirection(AngleToPoint(spider.Spider.x,spider.Spider.y,snake.Snake.x,snake.Snake.y));
				spider.Spider.SetSpeed(80);
			}else{
				spider.Spider.SetSpeed(100);
			}

			for(int i=0;i<spider.netNr;i++){
				if(sqrt((snake.Snake.x-spider.Net[i].GetPosition().x)*(snake.Snake.x-spider.Net[i].GetPosition().x)+(snake.Snake.y-spider.Net[i].GetPosition().y)*(snake.Snake.y-spider.Net[i].GetPosition().y))<50){
					snake.Snake.SetSpeed(50);
					spider.frenzy=true;
					spider.Spider.ToPoint(snake.Snake);
					if(abs(spider.Spider.x-snake.Snake.x)+abs(spider.Spider.y-snake.Snake.y)<20){
						snakeCaptured();
						Running=true;
						FrameRate=60;
						App.SetFramerateLimit(FrameRate);
						goto mainMenu;
					}
					break;
				}else{
					spider.frenzy=false;
					if(!snake.ifUnder){
						snake.Snake.SetSpeed(100);
					}
				}
			}
			snake.ifUnder=false;
			for (int i=0;i<wormCount;i++){
				for(int j=0;j<5;j++){
					if(worm[i].tVisible[j]>0&&sqrt(pow(worm[i].tunel[j].GetPosition().x-snake.Snake.x,2)+pow(worm[i].tunel[j].GetPosition().y-snake.Snake.y,2))<30){
						snake.ifUnder=true;
					}
				}
				if(worm[i].above&&sqrt(pow(worm[i].Worm.x-snake.Snake.x,2)+pow(worm[i].Worm.y-snake.Snake.y,2))<20){
					wormCount--;
					worm[i]=worm[wormCount];
					snake.AddBody();
					snake.AddBody();
				}
			}
		}
		{//drawing the stage

		for(int i=0;i<wormCount;i++){
			worm[i].Go();
		}

		spider.Go();
		for(int i=0;i<wormCount;i++){
			if(worm[i].above){
				worm[i].rama.SetPosition(worm[i].Worm);
				worm[i].rama.Go();
				App.Draw(worm[i].rama);
			}
		}
		snake.Go();
		App.Draw(spider.Spidi);



		}
		if(snake.Confucius){
			GameScene.SetCenter(Random.Random(380,420),Random.Random(280,320));
		}else{
			GameScene.SetCenter(400,300);
		}
		Score+=pow(snake.bodyParts,3.f)/1000000;
		App.Display();
	}//ending the game loop

}
