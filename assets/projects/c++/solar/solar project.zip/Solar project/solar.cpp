 #include <cmath>
 #include <iostream>
 #include <SFML/Graphics.hpp>
 #include <SFML/System.hpp>

 #include "Header/MySFML.hpp"

 const int number=1000;
 float G;
 int numberLeft=number;
 float randomness;
 float rad;
 float radMultiplier;

 using namespace std;
 using namespace sf;

 RenderWindow app;
 View timeSpace;

 Corp piece[number];
 Shape planet[number];
 float radius[number];

int main(){
Start:
{//user input part
	do{
		cout<<"Scrie numarul \"miniplanetelor\" care vor forma sistemul solar (intre 2 si 1000):";
		cin>>numberLeft;
	}while(numberLeft<1||numberLeft>1000);
	do{
		cout<<"Scrie \"G\",constanta gravitatinala (intre 100 si 100000):";
		cin>>G;
	}while(G<100||G>100000);
	do{
		cout<<"La inceput \"miniplanetelor\" li se dau o viteza initiala intimplatoare. Scrie cat de mare va fi aceasta (intre 0 si 199.9):";
		cin>>randomness;
	}while(randomness<0||randomness>200);
	do{
		cout<<"\"Miniplanetele\" vor fi reprezentate ca niste cercuri si vor avea o raza, scrieti marimea ei (intre 1 si 9.999):";
		cin>>rad;
	}while(rad<1||rad>10);
	do{
		cout<<"Sa se vada mai bine puteti mari raza planetei, dar ciocnirile vor aparea mai ciudate...: (intre 1 si 9.999):";
		cin>>radMultiplier;
	}while(radMultiplier<1||radMultiplier>10);
	cout<<"Ai 3 secunde sa minimalizezi consola.";
	Sleep(3.f);
}//user input end
{//initialization part
	app.Create(VideoMode(600,600,32),"Project solar system");
	timeSpace.SetFromRect(FloatRect(0,0,600,600));
	app.SetView(timeSpace);
	Randomizer temp;
	for (int i=0;i<numberLeft;i++){
		piece[i].Initialize(app);
		piece[i].Mass=1;
		temp.SetSeed(temp.Random(0,100000));
		float tempR=sqrt(temp.Random(0.f,600*600.f));
		float tempU=temp.Random(0,600);
		piece[i].x=cos(tempU)*tempR+300;
		piece[i].y=sin(tempU)*tempR+300;
		piece[i].SetSpeed(temp.Random(-1,1)*randomness,temp.Random(-1,1)*randomness);
	}
	for (int i=0;i<numberLeft;i++){
		radius[i]=rad;
		planet[i]=Shape::Circle(0,0,radius[i]*radMultiplier,Color(0,0,0));
	}
}//initialization end
//some necesari clearing before the main loop (reset last frame time)
	app.Clear(Color(100,100,100));
	app.Display();
	app.Clear(Color(100,100,100));
	app.Display();
{//the main loop
	bool terminate=false;
	while(!terminate){
		float D,Dx,Dy,A;
		for(int i=0;i<numberLeft;i++){		//colision detection
			for(int j=i+1;j<numberLeft;j++){
				bool colision;
				do{
					colision=false;
					Dx=piece[j].x-piece[i].x;
					Dy=piece[j].y-piece[i].y;
					D=sqrt(Dx*Dx+Dy*Dy);
					if(D<radius[i]+radius[j]){
						piece[i].SetSpeed((piece[i].Mass*piece[i].GetSpeedX()+piece[j].Mass*piece[j].GetSpeedX())/(piece[i].Mass+piece[j].Mass),(piece[i].Mass*piece[i].GetSpeedY()+piece[j].Mass*piece[j].GetSpeedY())/(piece[i].Mass+piece[j].Mass));
						piece[i].Mass+=piece[j].Mass;
						piece[i].x+=piece[j].Mass/piece[i].Mass*Dx;
						piece[i].y+=piece[j].Mass/piece[i].Mass*Dy;
						radius[i]=pow(pow(radius[j],3)+pow(radius[i],3),1.f/3);
						planet[i]=Shape::Circle(0,0,radius[i]*radMultiplier,Color(0,0,0));
						numberLeft--;
						piece[j]=piece[numberLeft];
						planet[j]=planet[numberLeft];
						radius[j]=radius[numberLeft];
						if(j<numberLeft){
							colision=true;
						}
					}
				}while(colision);
			}
		}
		for(int i=0;i<numberLeft;i++){		//acceleration
			for(int j=i+1;j<numberLeft;j++){
				Dx=piece[j].x-piece[i].x;
				Dy=piece[j].y-piece[i].y;
				D=sqrt(Dx*Dx+Dy*Dy);
				piece[i].Accelerate(G*piece[j].Mass*Dx/D/D/D,G*piece[j].Mass*Dy/D/D/D);
				piece[j].Accelerate(-G*piece[i].Mass*Dx/D/D/D,-G*piece[i].Mass*Dy/D/D/D);
			}
		}
		for(int i=0;i<numberLeft;i++){
			piece[i].Go();
			planet[i].SetPosition(piece[i]);
		}
		app.Clear(Color(255,255,255));
		for (int i=0;i<numberLeft;i++){
			app.Draw(planet[i]);
		}
		app.Display();
	{//event handling
		float x,y;
		bool lastMoved;
		Event Event;
		while(app.GetEvent(Event)){
			if(Event.Type==Event::Closed){
				terminate=true;
				app.Close();
			}
			if(Event.Type==Event::MouseWheelMoved){
				timeSpace.Zoom(1+(float)Event.MouseWheel.Delta/10);
			}
			if(Event.Type==Event::MouseButtonPressed){
				lastMoved=true;
				x=app.GetInput().GetMouseX();
				y=app.GetInput().GetMouseY();
			}
			if(Event.Type==Event::MouseButtonReleased){
				lastMoved=false;
			}
		}
		if(lastMoved){
			timeSpace.Move((x-app.GetInput().GetMouseX())*timeSpace.GetHalfSize().x/300,(y-app.GetInput().GetMouseY())*timeSpace.GetHalfSize().x/300);
			x=app.GetInput().GetMouseX();
			y=app.GetInput().GetMouseY();
		}
	}//event handling end
	}//whiie
}//main loop end
cout<<"\nInca odata? (d sau n)";
char raspuns;
cin>>raspuns;
if(raspuns=='d'){
	goto Start;
}
	return 0;
}
