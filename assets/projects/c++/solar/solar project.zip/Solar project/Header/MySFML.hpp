#include <SFML\System.hpp>
#include <SFML\Graphics.hpp>
#include <SFML\Window.hpp>
#include <SFML\Network.hpp>
#include <SFML\Audio.hpp>
#include "Animation.hpp"
#include "Corp.hpp"
namespace sf{
///....................................................................................................................................................................................................
///My mini clases
///....................................................................................................................................................................................................
class MyClock:public Clock{
public:
	void SetTime(float start){
		Reset();
		myStartTime+=start;
	}
	void AddTime(float time){
		myStartTime+=time;
	}
	float GetRemainingTime(){
		return -GetElapsedTime();
	}
};
}//end of namespace
namespace sf{//start of namespace
	class FunctionStack{




	};
}//end of namespace
