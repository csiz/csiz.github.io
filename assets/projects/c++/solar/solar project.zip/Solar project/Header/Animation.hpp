#include <SFML/System.hpp>
#include <SFML/Graphics.hpp>
#include <cmath>


namespace sf{
	//a usefull function:
	inline float AngleToInterval(float unghi){
		unghi=fmod((360+fmod(unghi,360)),360);
		unghi=unghi>180?unghi-360.f:unghi;
		return unghi;
	}
	inline float AngleToPoint(float x, float y, float tx, float ty){
		return -(tx-x>0?180*atan((ty-y)/(tx-x))/3.141592 : 180+180*atan((ty-y)/(tx-x))/3.141592);
	}
	class Animation:public Sprite{
	private:
		RenderWindow* Fereastra;
		bool Playing;
		Clock LastPlayed;
		int Width;
		int Height;
	//frames
		int Frames;
		float CurFrame;
		float FPS;

	public:
		inline void NextFrame();
		inline void PreviousFrame();
		void GoToFrame(float);
		inline void GoToLastFrame();
		inline void GoToFirstFrame();

		void Play();
		void Pause();
		void Stop();
		void SetFps(float);

		inline bool GetPlay();
		inline float GetCurentFrame();
		inline float GetFps();
	//init&go
		void Go();
		void Initialize(RenderWindow&,int,int,Image&,int,float);
	};

//namespace sf{//namespace begin
//	class Corp:public Vector2f{
//	private:
//		RenderWindow* Fereastra;
//		float SpeedX;
//		float SpeedY;
//		float Speed;
//		float Direction;float Rotation;
//	public:
//		float Mass;
//		void Initialize(RenderWindow&);
//	//Apearance
//		inline void SetRotation(float);
//		inline float GetRotation();
//	//movement
//		void SetSpeed(float);
//		void SetSpeed(float, float);
//		void SetDirection(float);
//
//		inline float GetDirection();
//		inline float GetSpeed();
//		inline float GetSpeedX();
//		inline float GetSpeedY();
//
//		inline void ToPoint(Vector2f);
//		inline void ToPoint(float, float);
//		inline void ChangeDirection(float);
//
//		inline void Accelerate(float);
//		inline void Accelerate(float,float);
//		inline void Force(float);
//		inline void Force(float, float);
//	//interaction
//		inline float GetDistance(float X, float Y);
//	//go ofcourse
//		inline void Go();
//	};
//}//the namespace sf end






//Animation class......................................................................................................................................................................................
	inline void Animation::NextFrame(){
		GoToFrame(CurFrame+1<Frames?CurFrame+1:0);
	}
	inline void Animation::PreviousFrame(){
		GoToFrame(CurFrame-1>0?CurFrame-1:Frames-1);
	}
	void Animation::GoToFrame(float i){
		IntRect Crop((int)i*Width,0,((int)i+1)*Width,Height);
		SetSubRect(Crop);
		CurFrame=i;
	}
	inline void Animation::GoToLastFrame(){
		GoToFrame(Frames-1);
	}
	inline void Animation::GoToFirstFrame(){
		GoToFrame(0);
	}
	void Animation::Play(){
		LastPlayed.Reset();
		Playing=true;
	}
	void Animation::Pause(){
		Playing=false;
	}
	void Animation::Stop(){
		Playing=false;
		GoToFrame(0.f);
	}
	void Animation::SetFps(float f){
		FPS=f;
	}
	inline bool Animation::GetPlay(){
		return Playing;
	}
	inline float Animation::GetFps(){
		return FPS;
	}
	inline float Animation::GetCurentFrame(){
		return CurFrame;
	}
	void Animation::Go(){
		if(Playing){
			CurFrame=fmod((LastPlayed.GetElapsedTime()*FPS+CurFrame),Frames);
			GoToFrame(CurFrame);
			LastPlayed.Reset();
		}
	}
	void Animation::Initialize(RenderWindow& Fer,int w,int h, Image &Img, int NrFr, float NrFps){
	//Image
		Width=w;
		Height=h;
		SetImage(Img);
	//Window
		Fereastra=&Fer;
	//Frames
		CurFrame=0.f;
		Frames=NrFr;
		FPS=NrFps;
	//stoping the play
		Playing=false;
		GoToFirstFrame();
	}
////Corp class...........................................................................................................................................................................................
//	inline void Corp::SetRotation(float r){
//		Rotation=r;
//	}
//	inline float Corp::GetRotation(){
//		return Rotation-Direction;
//	}
//	void Corp::SetSpeed(float speed){
//		SpeedX=(float)cos(Direction/180*3.141592)*speed;
//		SpeedY=(float)sin(Direction/180*3.141592)*speed;
//		Speed=speed;
//	}
//	void Corp::SetSpeed(float X,float Y){
//		SpeedX=X;
//		SpeedY=Y;
//		Speed=(float)sqrt(X*X+Y*Y);
//		Direction=SpeedX>0?180*atan(SpeedY/SpeedX)/3.141592:180+180*atan(SpeedY/SpeedX)/3.141592;
//	}
//	void Corp::SetDirection(float dir){
//		Direction=-dir;
//		SpeedX=(float)cos(Direction/180*3.141592)*Speed;
//		SpeedY=(float)sin(Direction/180*3.141592)*Speed;
//	}
//	inline float Corp::GetDirection(){
//		return -Direction;
//	}
//	inline float Corp::GetSpeed(){
//		return Speed;
//	}
//	inline float Corp::GetSpeedX(){
//		return SpeedX;
//	}
//	inline float Corp::GetSpeedY(){
//		return SpeedY;
//	}
//	inline void Corp::ToPoint(float X, float Y){
//		X-=x;Y-=y;
//		Direction=X>0?180*atan(Y/X)/3.141592:180+180*atan(Y/X)/3.141592;
//		SpeedX=(float)cos(Direction/180*3.141592)*Speed;
//		SpeedY=(float)sin(Direction/180*3.141592)*Speed;
//	}
//	inline void Corp::ToPoint(Vector2f v){
//		ToPoint(v.x,v.y);
//	}
//	inline void Corp::ChangeDirection(float rel){
//		SetDirection(-Direction+rel*Fereastra->GetFrameTime());
//	}
//	inline void Corp::Accelerate(float a){
//		SetSpeed(Speed+a*Fereastra->GetFrameTime());
//	}
//	inline void Corp::Accelerate(float ax, float ay){
//		SetSpeed(SpeedX+ax*Fereastra->GetFrameTime(),SpeedY+ay*Fereastra->GetFrameTime());
//	}
//	inline void Corp::Force(float f){
//		Accelerate(f/Mass);
//	}
//	inline void Corp::Force(float fx,float fy){
//		Accelerate(fx/Mass,fy/Mass);
//	}
//	inline float Corp::GetDistance(float X, float Y){
//		return sqrt((X-x)*(X-x)+(Y-y)*(Y-y));
//	}
//	inline void Corp::Go(){
//		x+=SpeedX*Fereastra->GetFrameTime();
//		y+=SpeedY*Fereastra->GetFrameTime();
//	}
//	void Corp::Initialize(RenderWindow& Fer){
//	//Window
//		Fereastra=&Fer;
//	//la zero
////		SpeedX=0;
////		SpeedY=0;
////		Speed=0;
////		Direction=0;Rotation=0;
////		x=0;
////		y=0;
////		Mass=1;
//	}
}//exit the namespace











